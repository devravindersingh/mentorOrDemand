const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const config = require('../config/database');

//mentor schema
const mentorSchema = mongoose.Schema({
    firstName: {
        type: String,
        required: true
    },
    secondName: {
        type: String
    },
    email: {
        type: String,
        required: true
    },
    password:{
        type: String,
        required: true
    },
    contactNumber: {
        type: Number,
        required: true
    },
    linkedURL: {
        type: String
    },
    role: {
        type: String
    },
    yearsOfExp: {
        type: Number,
        required: true
    },
    descrp:{
        type: String
    },
    active: {
        type: Boolean
    },
    confirmedSignUp: {
        type: Boolean
    },
    resetPassword: {
        type: Boolean
    },
    resetPasswordDate: {
        type: Date,
    }
})