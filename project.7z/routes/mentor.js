const express = require('express');
const router = express.Router();

//login/authenticate
router.get('/login',(req,res,next)=>{
    res.send('authenticate');
})

//register

router.post('/register',(req,res,next)=>{
    res.send('register');
})

//profile
router.get('/profile',(req,res,next)=>{
    res.send('profile');
})

module.exports = router;
