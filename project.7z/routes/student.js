const express = require('express');
const router = express.Router();
const student = require('../models/student');
const passport = require('passport');
const jwt = require('jsonwebtoken');

//login/authenticate
router.get('/login',(req,res,next)=>{
    res.send('authenticate');
})

//register
router.post('/register',(req,res,next)=>{
    let newStudent = new student({
        firstName: req.body.firstName,
        secondName: req.body.secondName,
        email: req.body.email,
        password: req.body.password,
        contactNumber: req.body.contactNumber,
        role: "student",
        active: req.body.active,
        confirmedSignUp: req.body.confirmedSignUp,
        resetPassword: req.body.resetPassword,
        resetPasswordDate: req.body.resetPasswordDate,
    });

    student.addStudent(newStudent, (err, user)=>{
        if(err){
            res.json({success: false, msg: 'failed to register user'});
        }
        else{
            res.json({success: true, msg: 'successfully registered user'});
        }
    });
});

//profile
router.get('/profile',(req,res,next)=>{
    res.send('profile');
})

//editing data
router.get('/edit',(req,res,next)=>{
    res.send('editdata');
})

//coursedetails  -- need technolgies id for display content
router.get('/courseDetails',(req,res,next)=>{
    res.send('details of course');
})

//searching -- need the qurey in techid, calendar details
router.get('/search',(req,res,next)=>{
    res.send('searching for mentors');
})


module.exports = router;